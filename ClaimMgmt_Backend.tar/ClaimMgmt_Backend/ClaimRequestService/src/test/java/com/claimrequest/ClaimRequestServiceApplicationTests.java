package com.claimrequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimRequestServiceApplicationTests {

	@Test
	void contextLoads() {
		//test
	}

}

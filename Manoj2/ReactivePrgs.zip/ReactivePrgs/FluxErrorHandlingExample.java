package flux.paxk1;
import reactor.core.publisher.Flux;

public class FluxErrorHandlingExample {
    public static void main(String[] args) {
        Flux<Integer> numbers = Flux.just(1, 2, 0, 4)
            .map(n -> 10 / n) // This will throw ArithmeticException when n = 0
            .doOnError(e -> System.out.println("Error occurred: " + e.getMessage()))
            ;

        numbers.subscribe(
            value -> System.out.println("Received: " + value),
            error -> System.out.println("Final error: " + error),
            () -> System.out.println("Stream completed")
        );
    }
}

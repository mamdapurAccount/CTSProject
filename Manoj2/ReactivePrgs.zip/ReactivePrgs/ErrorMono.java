package flux.paxk1;
import reactor.core.publisher.Mono;

public class ErrorMono {
    public static void main(String[] args) {
        Mono<String> errorMono = Mono.
        		error(new RuntimeException("Something went wrong!"));
        errorMono.subscribe(
            value -> System.out.println("Received: " + value),
            error -> System.err.println("Error: " + error.getMessage())
        );
    }
}

package flux.paxk1;
import reactor.core.publisher.Mono;

class Student {
    private  String name;
    private  int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + "}";
    }
}

public class StudentMonoExample {
    public static void main(String[] args) {

        // Example with onErrorReturn
        Mono<Student> monoWithOnErrorReturn =
        		Mono.
        		<Student>
        error(new RuntimeException("Database not reachable"))
                .onErrorReturn(new Student("Default Student", 0));

        monoWithOnErrorReturn.subscribe(
                student -> System.out.println("Received: " + student),
                err -> System.err.println("Error: " + err)
        );

        // Example with onErrorResume
        Mono<Student> monoWithOnErrorResume = 
        		Mono.<Student>error(new IllegalArgumentException("Invalid student ID"))
                .onErrorResume(error -> {
                    System.out.println("Handling error: " + error.getMessage());
                    if (error instanceof IllegalArgumentException) {
                        return Mono.just(new Student("Recovered Student", 18));
                    } else {
                        return Mono.just(new Student("Unknown Student", -1));
                    }
                });

        monoWithOnErrorResume.subscribe(
                student -> System.out.println("Received: " + student),
                err -> System.err.println("Error: " + err)
        );
    }
}

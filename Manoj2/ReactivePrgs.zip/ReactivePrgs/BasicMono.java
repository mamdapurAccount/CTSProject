package flux.paxk1;
import reactor.core.publisher.Mono;

public class BasicMono {
    public static void main(String[] args) {
        Mono<String> mono = Mono.just("Hello, Reactive World!");
        //public void run()
        mono.subscribe(obj->System.out.println(obj),
        		error->System.out.println(error),
        		()->System.out.println("completed"));
    }
}

package flux.paxk1;

import reactor.core.publisher.Flux;

public class TestFluxDemo4 {

	public static void main(String[] args) {
		Flux<String> flux1=Flux.just("hi","hello");
		Flux<String> flux2=Flux.just("aas","sdsd");
		Flux.concat(flux1,flux2).subscribe(System.out::println);

	}

}

package flux.paxk1;
import reactor.core.publisher.Mono;

public class TransformMono {
    public static void main(String[] args) {
        Mono<Integer> mono = Mono.just("123")
                                 .map(Integer::parseInt)
                                 .map(n -> n * 2);

        mono.subscribe(System.out::println); // Output: 246
    }
}

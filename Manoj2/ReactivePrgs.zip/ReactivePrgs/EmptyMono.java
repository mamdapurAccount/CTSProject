package flux.paxk1;
import reactor.core.publisher.Mono;

public class EmptyMono {
    public static void main(String[] args) {
        Mono<String> emptyMono = Mono.empty();
        emptyMono.subscribe(
            value -> System.out.println("Received: " + value),
            error -> System.err.println("Error: " + error),
            () -> System.out.println("Completed with no value")
        );
    }
}

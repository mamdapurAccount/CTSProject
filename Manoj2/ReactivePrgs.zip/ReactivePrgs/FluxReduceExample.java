package flux.paxk1;
import reactor.core.publisher.Flux;

public class FluxReduceExample {
    public static void main(String[] args) {
        Flux<Integer> numbers = Flux.just(1, 2, 3, 4, 5);

        // Reduce without initial value
        numbers.reduce((a, b) -> a + b)
               .subscribe(sum -> System.out.println("Sum: " + sum));

        // Reduce with initial value
        numbers.reduce(10, (a, b) -> a + b)
               .subscribe(sum -> System.out.println("Sum with initial value: " + sum));
    }
}

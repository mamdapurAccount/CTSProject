package flux.paxk1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import reactor.core.publisher.Flux;

class Flight implements Serializable
{
	private long flightId;
	private String flightName;
	private double flightPrice;
	public Flight(long flightId, String flightName, double flightPrice) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightPrice = flightPrice;
	}
	public long getFlightId() {
		return flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public double getFlightPrice() {
		return flightPrice;
	}
	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", flightPrice=" + flightPrice + "]";
	}
	
	
}
public class TestFluxDemo2 {
	
	
	

	public static void main(String[] args) {
		List<Flight> list=new ArrayList<Flight>();
		list.add(new Flight(1087, "Indigo", 35555.00));
		list.add(new Flight(1687, "SpiceJet", 65555.00));
		list.add(null);
		list.add(new Flight(2007, "AirIndia", 65555.00));
		
	Stream<Flight> stream=list.stream().filter(f->f!=null);
		
	Flux<Flight> flux=	Flux.fromStream(stream).filter(f->f!=null).map(flight-> 
		{
			if(flight==null)
			{
			throw new RuntimeException("Invalid id");
				
		}
		else
		{
			return flight;
		}
			
		}
		).onErrorContinue
			((error, obj)->System.out.println(error.getMessage()));
		
		
	
		flux.
		
		subscribe(obj->System.out.println(obj));

	}

}

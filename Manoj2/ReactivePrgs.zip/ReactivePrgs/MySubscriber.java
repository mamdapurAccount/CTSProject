package flux.paxk1;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

public class MySubscriber implements Subscriber {

	@Override
	public void onSubscribe(Subscription subscription) {
		
		subscription.request(Long.MAX_VALUE);
	}

	@Override
	public void onNext(Object obj) {
		System.out.println("Data:"+" "+obj);
		
	}

	@Override
	public void onError(Throwable t) {
		System.out.println(t.getMessage());
		
	}

	@Override
	public void onComplete() {
		System.out.println("All data are piblished");
		
	}

}

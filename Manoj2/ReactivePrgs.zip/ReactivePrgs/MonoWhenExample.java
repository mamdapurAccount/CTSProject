package flux.paxk1;
import reactor.core.publisher.Mono;

public class MonoWhenExample {
    public static void main(String[] args) {
        Mono<Void> task1 = Mono.fromRunnable(() -> {
            System.out.println("Task 1 running");
        });

        Mono<Void> task2 = Mono.fromRunnable(() -> {
            System.out.println("Task 2 running");
        });

        // Combine tasks: completes when both are done
        Mono<Void> combined = Mono.when(task1, task2);

        combined.block(); // Wait for completion
        System.out.println("All tasks completed!");
    }
}

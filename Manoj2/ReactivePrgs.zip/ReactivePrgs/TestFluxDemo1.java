package flux.paxk1;

import reactor.core.publisher.Flux;

public class TestFluxDemo1 {
	
	
	static Flux<String> taskData(int day)
	{
		return switch(day)
				{
		case 1, 2 ,3->Flux.just("stage0 , stage1").log();
		case 4,5,6->Flux.just("project developemnt").log();
		case 7->Flux.error(new RuntimeException("Error in code"));
		default -> Flux.empty();
				};
	}

	public static void main(String[] args) {
		//taskData(1).subscribe(data->System.out.println(data));
    // taskData(7).subscribe(n->System.out.println());
		MySubscriber s=new MySubscriber();
		taskData(7).subscribe(s);
     
	}

}

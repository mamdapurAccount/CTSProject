package com.cts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class FoodDb {
	static HashMap<Integer,Food> db= new HashMap<>();
	
   static {
	   db.put(1, new Food(1, "Dal"));
	   db.put(2, new Food(2, "Biryani"));
	   db.put(3, new Food(3, "Maggie"));
	   
   }
   public List<Food> getFoods(){
	   return new ArrayList<Food>(db.values());
	   
   }
   public Food getFood(int id) {
	   return db.get(id);
   }
	
}

package com.cts;

public class Food {

	int foodId;

	String foodName;
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public Food(int foodId, String foodName) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
	}
	public Food() {
		super();
	
	}
	@Override
	public String toString() {
		return "Food [foodId=" + foodId + ", foodName=" + foodName + "]";
	}

}

package com.cts;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class Test {

	public static void main(String[] args) {
		
		//Mono<String> mn= Mono.just("Shankar I Love you");
	   // mn.subscribe((c)->System.out.println(c),(e)->System.out.println(e.getMessage()),()->System.out.println("completed"));
	   
//	    Mono<String> mn= Mono.empty();
//		mn.subscribe((c)->System.out.println(c),(e)->System.out.println(e.getMessage()),()->System.out.println("completed"));

	//	Mono<String> mn= Mono.error(new RuntimeException("Some error"));
	//	   mn.subscribe((c)->System.out.println(c),(e)->System.out.println(e.getMessage()),()->System.out.println("completed"));
	
		// **************************************************
		
	//	Flux<Integer> nums= Flux.just(10,20,30);
		//nums.subscribe((c)->System.out.println(c),(e)->System.out.println(e.getMessage()),()->System.out.println("Compe"));
		
		
		//****************************************************
		
	//	Flux<Integer> nums=	Flux.just(10,20,30).map((c)->c*2)
		//.doOnNext((c)->System.out.println(c));
//nums.blockLast();
//nums.subscribe((c)->System.out.println(c));
	//System.out.println("Mian rip");

//*******************************************************

//		Flux<Integer> nums = Flux.just(1,2,0,4).map((c)->10/c).doOnError((e)->System.out.println(e.getMessage()));
//		nums.subscribe((c)->System.out.println(c),(e)->System.out.println(e.getMessage()),()->System.out.println("Comple"));
//		
//		System.out.println("Main RIP");
		

		//**********************************************
		//Flux<Integer> nums= Flux.just(10,20,30)
		//		            .delayElements(Duration.ofSeconds(2))
			//	            .doOnNext((c)->System.out.println(c));
		
		//nums.subscribe((c)->System.out.println(c));
		//nums.blockLast();  // subscribes and emits the stream
	//	System.out.println("Main RIP");

//		try {
//			Thread.sleep(8000);
//		}
//		catch(Exception e) {}
//		System.out.println("Main Rip");
		
		//*********************************************************
	//	 Flux<Integer> numbers = Flux.just(1, 2, 3, 4, 5);

	        // Reduce without initial value
	  //      numbers.reduce((a, b) -> a + b)
	    //           .subscribe(sum -> System.out.println("Sum: " + sum));

	        // Reduce with initial value
	      //  numbers.reduce(10, (a, b) -> a + b)
	        //       .subscribe(sum -> System.out.println("Sum with initial value: " + sum));
	
		
	//****************************************************************
		
		  List<String> al= List.of("hello manoj","hello janu");
		  
	     List<String> al1= al.stream().flatMap((s)->Arrays.stream(s.split(" "))).collect(Collectors.toList());
	     
	         System.out.println(al1);
	      
	      // Flux<String> str=  Flux.just("Hello manoj","hello saba","hello sana").flatMap((s)->Flux.fromArray(s.split(" ")));
	         
	      
	     // str.subscribe((c)->System.out.println(c));
	      
	      
	      
	         //**************************************************************************************
	         
	}

}

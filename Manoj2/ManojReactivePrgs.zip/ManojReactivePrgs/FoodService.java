package com.cts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FoodService {
	@Autowired
	FoodDb db;
	
	public Food getFood(int id) {
		return db.getFood(id);
	}
	public List<Food> getFoods(){
		return db.getFoods();
	}
}

package com.cts;

import reactor.core.publisher.Flux;

public class MyMain {

	public static void main(String[] args) {
		Flux<String> str= Flux.just("saba",null,"janu","lotu").map((s)->s);
	
		str.subscribe((e)->System.out.println(e),(e)->System.out.println(e.getMessage()),()->System.out.println("Comple"));
		
		System.out.println("Main rip");

	}

}

package com.cts;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class FoodController {

	@Autowired
	FoodService service;
	
	@GetMapping("/food")
	public Mono<Food> getFood(){
		return Mono.just(service.getFood(2));
		
	}
	
	@GetMapping("/foods")
	public Flux<Food> getFoods(){
		return Flux.fromIterable(service.getFoods());
			
	}
	
	@GetMapping("/mono")
	public Mono<String> getMono(){
		return Mono.just("Manu");
	}
	
	@GetMapping("/flux")
	public Flux<String> getFlux(){
		return Flux.just("Saba","Sana","Saima").delayElements(Duration.ofSeconds(2));
		
	}
	@GetMapping("/map")
	public List<String> getMap(){
         List<String> al= Arrays.asList("hello manoj","hello janu");
         List<String> al1= al.stream().map((s)->s).collect(Collectors.toList());
         
         return al1;
         
	}
	@GetMapping("/map1")
	public Flux<String> getFlap3(){
         List<String> al= List.of("Janu","Lotu","Mandu","Chandu");
        return  Flux.fromIterable(al).map((f)->f);
                
	}
	@GetMapping("/flatmap")
	public List<String> getFlap1(){
         List<String> al= Arrays.asList("hello manoj","hello janu");
         List<String> al1= al.stream().flatMap((s)->Arrays.stream(s.split(" "))).collect(Collectors.toList());
         
         return al1;
         
	}
	@GetMapping("/flatmap1")
	public Flux<String> getFlap2(){
         List<String> al= List.of("Hello Janu","Hello Manoj");
        return Flux.fromIterable(al).flatMap((s)->Flux.fromArray(s.split(" ")));
        
         
	}
	@GetMapping("/filter")
	public List<Food> getfileter(){
		List<Food> al = service.getFoods();
		
		List<Food> al1=al.stream().filter((f)->f.getFoodId()>1).collect(Collectors.toList());
		
		return al1;
		
	}
	@GetMapping("/filter1")
	public Flux<Food> getfileter1(){
		List<Food> al = service.getFoods();
		
		return  Flux.fromIterable(al).filter((f)->f.getFoodId()>1);
		
	
		
	}
	}

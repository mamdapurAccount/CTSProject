package com.cts;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class TestMain {
	

	
	
	public static void main(String[] args) {
	  
		  Flux<Integer> f= Flux.just(10,20,30);
		  
		//  f.reduce((a,b)->a+b).subscribe((sum)->System.out.println(sum));
		  
		  f.reduce(5,(a,b)->a+b).subscribe((sum)->System.out.println(sum));
		  
   
		
		
	}
	

}

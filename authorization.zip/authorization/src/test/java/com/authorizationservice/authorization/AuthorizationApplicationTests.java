package com.authorizationservice.authorization;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}

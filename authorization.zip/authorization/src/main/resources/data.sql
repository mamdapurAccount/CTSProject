insert into Authentication_request (user_name, password) values ('adyasha1', 'adyasha1');
insert into authentication_request (user_name, password) values ('abhishek2', 'abhishek2');
insert into authentication_request (user_name, password) values ('satvik3', 'satvik3');
insert into authentication_request (user_name, password) values ('amit4', 'amit4');
insert into authentication_request (user_name, password) values ('someUser5', 'someUser5');